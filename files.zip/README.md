# Plano de Estudos — Desenvolvimento Front-end 🚀

## Objetivo
Em 30 dias, 1h por dia, construir uma base sólida em desenvolvimento front-end —
entendendo HTML, CSS, lógica, JavaScript e Git para criar minha primeira página web do zero.

## Contexto
Bootcamp Santander (DIO) + estudos complementares de front-end.
Background em costura → transição de carreira para tecnologia.

## Como usar esta pasta

| Arquivo | O que é |
|---|---|
| `cronograma.md` | Roteiro semanal com dias, metas e dicas |
| `recursos.md` | Materiais e links separados por semana |
| `anotacoes/` | Minhas anotações de cada semana de estudo |

## Tópicos cobertos
1. HTML — estrutura de páginas web
2. CSS — estilização e visual
3. Lógica de programação
4. JavaScript básico
5. Git e GitHub

## Regra de ouro
> Consistência bate velocidade. 1h por dia, todos os dias, sem pular.
