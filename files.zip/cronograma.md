# Cronograma — 30 Dias de Front-end

---

## Semana 1 — HTML: o esqueleto da web

**Meta:** ter uma página "Sobre mim" com foto, texto e lista de hobbies funcionando no navegador.
**Ferramenta:** VS Code + extensão Live Server

| Dia | O que estudar |
|---|---|
| Dia 1 | O que é HTML? Estrutura básica: html, head, body |
| Dia 2 | Tags de texto: h1-h6, p, strong, em, br |
| Dia 3 | Links e imagens: a href, img src, atributo alt |
| Dia 4 | Listas: ul, ol, li — começar a digitar o código |
| Dia 5 | Formulários básicos: input, button, label |
| Dia 6 | Semântica HTML: header, main, section, footer |
| Dia 7 | 🎯 Desafio: criar a página "Sobre mim" só com HTML |

**Dica:** Não tente memorizar tudo. Anota o que achar importante e pesquisa o resto. Todo dev usa Google o tempo todo — isso é normal.

**Erro mais comum:** querer que fique bonita antes de funcionar. Foca em funcionar primeiro!

---

## Semana 2 — CSS: deixando tudo bonito

**Meta:** a página "Sobre mim" estilizada, com fonte bonita, cores e funcionando bem no celular também.

| Dia | O que estudar |
|---|---|
| Dia 8 | O que é CSS? Seletores, propriedades e valores |
| Dia 9 | Box model — como cada elemento ocupa espaço na tela |
| Dia 10 | Margin, padding, border — é a base de tudo, não pule! |
| Dia 11 | Flexbox: alinhamento e distribuição de elementos |
| Dia 12 | Flexbox Froggy: jogue no mínimo 30 min |
| Dia 13 | Responsividade: media queries e unidades relativas |
| Dia 14 | 🎯 Desafio: estilizar a página da semana 1 |

**Dica:** É jogando o Flexbox Froggy que o Flexbox entra na cabeça!
**Teste:** redimensione a janela do navegador para ver se o layout se adapta no celular.

---

## Semana 3 — Lógica + JavaScript básico

**Meta:** um botão que faça algo na página — mudar cor, mostrar mensagem ou contar cliques.
Simples, mas poderoso para entender a lógica!

| Dia | O que estudar |
|---|---|
| Dia 15 | Variáveis e tipos de dados (texto, número, booleano) |
| Dia 16 | Condições: if, else — pensa em português antes de codar |
| Dia 17 | Repetições: for e while |
| Dia 18 | Funções: blocos de código reutilizáveis |
| Dia 19 | JavaScript no navegador: alert, console.log, primeiro script |
| Dia 20 | Manipulando a página: getElementById, innerHTML |
| Dia 21 | 🎯 Desafio: botão que muda texto ou cor ao clicar |

**Dica dias 15-18:** lógica pura, sem JavaScript ainda. Pensa em português: "se a pessoa clicar, então muda a cor".
**Dica dias 19-21:** use o console do navegador (F12) pra testar — o console é seu melhor amigo!

---

## Semana 4 — Git, GitHub e projeto final

**Meta final:** link do GitHub Pages funcionando — seu portfólio número 1.
Guarda esse link — vai usar em currículos e vagas!

| Dia | O que estudar |
|---|---|
| Dia 22 | O que é Git? Instalar e configurar |
| Dia 23 | Comandos básicos: git init, add, commit |
| Dia 24 | GitHub: criar conta, repositório e primeiro push |
| Dia 25 | GitHub Pages: publicar sua página de graça |
| Dia 26 | Projeto final: planejar a página de portfólio |
| Dia 27 | Projeto final: HTML e CSS |
| Dia 28 | Projeto final: interação com JavaScript |
| Dia 29 | Projeto final: revisar e deixar responsivo |
| Dia 30 | 🎉 Publicar no GitHub Pages e compartilhar! |

**Dica dias 22-25:** pratique o fluxo todo dia: editar → salvar → commit → push. Não precisa entender tudo — só o fluxo básico já resolve!
**Dica dias 26-30:** ideia sugerida para o projeto — uma página de portfólio com seu nome, foto, habilidades e o projeto da semana 1/2. Simples e direto ao ponto.
