# Recursos e Materiais por Semana

---

## Semana 1 — HTML

| Tipo | Material | Link |
|---|---|---|
| Vídeo | Curso em Vídeo — HTML5 (Gustavo Guanabara) | https://www.youtube.com/watch?v=SV7TL0hxmIQ |
| Referência | MDN Web Docs — HTML em PT-BR | https://developer.mozilla.org/pt-BR/docs/Learn/HTML |
| Ferramenta | VS Code (editor de código gratuito) | https://code.visualstudio.com |

**Extensão obrigatória no VS Code:** Live Server — mostra o resultado no navegador em tempo real.

---

## Semana 2 — CSS

| Tipo | Material | Link |
|---|---|---|
| Vídeo | Curso em Vídeo — CSS3 (Gustavo Guanabara) | https://www.youtube.com/watch?v=vwbegroDXZs |
| Jogo | Flexbox Froggy — aprender Flexbox jogando | https://flexboxfroggy.com/#pt-br |
| Referência | MDN Web Docs — CSS | https://developer.mozilla.org/pt-BR/docs/Learn/CSS |

---

## Semana 3 — Lógica + JavaScript

| Tipo | Material | Link |
|---|---|---|
| Vídeo | Lógica de Programação — Curso em Vídeo | https://www.youtube.com/playlist?list=PLntvgXM11X6pi7mW0O4ZmfUI1xDSIbmTm |
| Texto | JavaScript.info — tutorial completo em PT-BR | https://javascript.info/pt |
| Ferramenta | Console do navegador (F12) | — |

---

## Semana 4 — Git e GitHub

| Tipo | Material | Link |
|---|---|---|
| Vídeo | Git e GitHub para iniciantes — Willian Justen | https://www.youtube.com/watch?v=DqTITcMq68k |
| Documentação | GitHub Pages — como publicar sua página | https://docs.github.com/pt/pages |
| Plataforma | GitHub | https://github.com |

---

## Materiais extras (para depois dos 30 dias)

| Tipo | Material | Link |
|---|---|---|
| Plataforma | Rocketseat — trilhas gratuitas | https://rocketseat.com.br |
| Jogo | CSS Grid Garden | https://cssgridgarden.com/#pt-br |
| Comunidade | Flexbox Froggy | https://flexboxfroggy.com/#pt-br |
